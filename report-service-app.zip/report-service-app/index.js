require("dotenv").config();
const express = require("express");
const app = express();
const morgan = require("morgan");
const helmet = require("helmet");
const reportRoutesV1 = require("./routes/v1/reports");
const { authenticateToken } = require("./middlewares/authMiddleware");
const { initializeKeyVault } = require("./services/keyVaultService");
const { initializeDBConnections } = require("./services/dbService");

// Middleware
app.use(helmet());
app.use(express.json());
app.use(morgan("combined"));

(async () => {
  await initializeKeyVault();
  await initializeDBConnections();

  app.use(authenticateToken);
  app.use("/api/v1/reports", reportRoutesV1);

  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
})();

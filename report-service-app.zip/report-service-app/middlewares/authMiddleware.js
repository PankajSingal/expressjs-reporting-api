const jwt = require("jsonwebtoken");
const jwksClient = require("jwks-rsa");

const client = jwksClient({
  jwksUri: process.env.AZURE_B2C_JWKS_URI,
});

function getKey(header, callback) {
  client.getSigningKey(header.kid, (err, key) => {
    const signingKey = key.getPublicKey();
    callback(null, signingKey);
  });
}

exports.authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, getKey, {
    audience: process.env.AZURE_B2C_CLIENT_ID,
    issuer: process.env.AZURE_B2C_ISSUER,
    algorithms: ["RS256"],
  }, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

const { DefaultAzureCredential } = require("@azure/identity");
const { SecretClient } = require("@azure/keyvault-secrets");

let secrets = {};

exports.initializeKeyVault = async () => {
  const credential = new DefaultAzureCredential();
  const vaultUrl = `https://${process.env.AZURE_KEY_VAULT_NAME}.vault.azure.net`;
  const client = new SecretClient(vaultUrl, credential);

  const secretNames = ["SQL_CONNECTION", "DRUID_URL"];
  for (let name of secretNames) {
    const retrieved = await client.getSecret(name);
    secrets[name] = retrieved.value;
  }
};

exports.getSecret = (name) => secrets[name];

const sql = require("mssql");
const axios = require("axios");
const { getSecret } = require("./keyVaultService");

exports.initializeDBConnections = async () => {
  const sqlConnectionString = getSecret("SQL_CONNECTION");
  await sql.connect(sqlConnectionString);
  console.log("Connected to SQL Server");

  const druidUrl = getSecret("DRUID_URL");
  const response = await axios.get(druidUrl + "/status");
  if (response.status === 200) {
    console.log("Connected to Druid");
  } else {
    throw new Error("Failed to connect to Druid");
  }
};

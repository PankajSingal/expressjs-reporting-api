const express = require("express");
const router = express.Router();
const {
  getImpactReport,
  getChecklistReport
} = require("../../controllers/reportController");

router.get("/impact", getImpactReport);
router.get("/checklist", getChecklistReport);

module.exports = router;

exports.getImpactReport = (req, res) => {
  res.json({ message: "Impact report data for " + req.user.name });
};

exports.getChecklistReport = (req, res) => {
  res.json({ message: "Checklist report data for " + req.user.name });
};

require('dotenv').config();
const app = require('./src/app');
const { initConfig, config } = require('./src/config/config');

initConfig().then(() => {
  app.listen(config.port, () => {
    console.log(`Server running on http://localhost:${config.port}`);
  });
}).catch(err => {
  console.error('App startup failed:', err.message);
});

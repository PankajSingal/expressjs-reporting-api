const { connectSQL } = require('../config/db/sqlserver');
const { druidQuery } = require('../config/db/druid');

exports.getDataFromSQL = async (req, res) => {
  const pool = await connectSQL();
  const result = await pool.request().query('SELECT TOP 10 * FROM Users');
  res.json(result.recordset);
};

exports.getDataFromDruid = async (req, res) => {
  const result = await druidQuery({
    queryType: 'topN',
    dataSource: 'wikiticker',
    dimension: 'page',
    threshold: 5,
    metric: 'count',
    intervals: ['2015-09-12T00:00:00.000Z/2015-09-13T00:00:00.000Z']
  });
  res.json(result);
};

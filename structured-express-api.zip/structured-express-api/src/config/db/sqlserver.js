const sql = require('mssql');
const { config } = require('../config');

let pool;

async function connectSQL() {
  if (pool) return pool;
  try {
    pool = await sql.connect(config.secrets.SQLSERVER_CONNECTION_STRING);
    console.log('Connected to SQL Server');
    return pool;
  } catch (err) {
    console.error('SQL Server connection failed:', err.message);
    throw err;
  }
}

module.exports = { connectSQL };

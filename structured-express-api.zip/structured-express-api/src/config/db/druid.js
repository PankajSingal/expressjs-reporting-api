const { DruidQuery } = require('druid-query-toolkit');
const { config } = require('../config');

function druidQuery(queryObject) {
  const query = DruidQuery.fromQuery(queryObject);
  return fetch(config.secrets.DRUID_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(query.query)
  }).then(res => res.json());
}

module.exports = { druidQuery };

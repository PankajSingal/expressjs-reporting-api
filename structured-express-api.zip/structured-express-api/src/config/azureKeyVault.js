const { DefaultAzureCredential } = require('@azure/identity');
const { SecretClient } = require('@azure/keyvault-secrets');

const vaultName = process.env.AZURE_KEY_VAULT_NAME;
const credential = new DefaultAzureCredential();
const vaultUrl = `https://${vaultName}.vault.azure.net`;
const client = new SecretClient(vaultUrl, credential);

async function loadSecrets(secretNames = []) {
  const secrets = {};
  for (const name of secretNames) {
    try {
      const secret = await client.getSecret(name);
      secrets[name] = secret.value;
    } catch (err) {
      console.error(`Failed to load secret ${name}:`, err.message);
    }
  }
  return secrets;
}

module.exports = { loadSecrets };

require('dotenv').config();
const { loadSecrets } = require('./azureKeyVault');

let config = {
  port: process.env.PORT || 3000,
  azure: {
    clientId: process.env.AZURE_CLIENT_ID,
    clientSecret: process.env.AZURE_CLIENT_SECRET,
    tenantId: process.env.AZURE_TENANT_ID,
    vaultName: process.env.AZURE_KEY_VAULT_NAME
  },
  secrets: {}
};

async function initConfig() {
  const secretKeys = ['SQLSERVER_CONNECTION_STRING', 'DRUID_URL'];
  const secrets = await loadSecrets(secretKeys);
  config.secrets = secrets;
  return config;
}

module.exports = { config, initConfig };

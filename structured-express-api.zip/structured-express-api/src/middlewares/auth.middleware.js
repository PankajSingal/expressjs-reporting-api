const { auth } = require('express-oauth2-jwt-bearer');

const tenantName = process.env.B2C_TENANT_NAME;
const policyName = process.env.B2C_POLICY;
const clientId = process.env.B2C_CLIENT_ID;

const issuerBaseUrl = `https://${tenantName}.b2clogin.com/${tenantName}.onmicrosoft.com/${policyName}/v2.0/`;

const jwtCheck = auth({
  audience: clientId,
  issuerBaseURL: issuerBaseUrl,
  tokenSigningAlg: 'RS256'
});

module.exports = jwtCheck;

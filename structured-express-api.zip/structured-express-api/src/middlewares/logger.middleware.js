const logger = require('../config/logger');

const requestLogger = (req, res, next) => {
  logger.info(`${req.method} ${req.originalUrl}`);
  res.on('finish', () => {
    logger.info(`Status: ${res.statusCode}`);
  });
  next();
};

module.exports = requestLogger;

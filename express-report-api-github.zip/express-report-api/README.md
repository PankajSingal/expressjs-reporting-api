# Express Report API

This is a sample Express.js project for querying Apache Druid and serving reports via RESTful APIs.

## Features
- Modular structure (controllers, services, routes)
- Swagger UI for API documentation (`/api-docs`)
- Druid query integration
- Reusable report sections
- Easily extendable

## Setup

1. Install dependencies:

```bash
npm install
```

2. Run the app:

```bash
node app.js
```

3. Access Swagger UI at: `http://localhost:3000/api-docs`

## Folder Structure

- `controllers/` - API logic
- `routes/` - Express routes
- `reports/` - Report composition
- `sections/` - Reusable data logic
- `druid/` - Druid DB integration
- `swagger.js` - Swagger config
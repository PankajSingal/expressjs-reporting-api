const express = require('express');
const router = express.Router();
const controller = require('../controllers/marketing.controller');

/**
 * @swagger
 * /api/marketing/daily:
 *   get:
 *     summary: Get daily report
 *     parameters:
 *       - in: query
 *         name: start
 *         schema:
 *           type: string
 *         required: true
 *         description: Start date
 *       - in: query
 *         name: end
 *         schema:
 *           type: string
 *         required: true
 *         description: End date
 *     responses:
 *       200:
 *         description: Report data
 */
router.get('/daily', controller.getDailyReport);

module.exports = router;
const dailyReportService = require('../reports/dailyReport.service');

async function getDailyReport(req, res) {
  const { start, end } = req.query;
  const data = await dailyReportService.buildDailyReport(start, end);
  res.json({ report: data });
}

module.exports = { getDailyReport };
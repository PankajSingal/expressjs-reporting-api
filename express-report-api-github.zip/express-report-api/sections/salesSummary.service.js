const druidService = require('../druid/druid.service');

async function getSalesSummary(start, end) {
  const query = {
    queryType: 'sql',
    sql: `SELECT SUM(sales) as total FROM sales_data WHERE __time >= TIMESTAMP '${start}' AND __time <= TIMESTAMP '${end}'`
  };
  const result = await druidService.query(query);
  return {
    totalSales: result[0]?.total || 0
  };
}

module.exports = { getSalesSummary };
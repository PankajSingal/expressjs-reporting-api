const salesSummary = require('../sections/salesSummary.service');

async function buildDailyReport(start, end) {
  const summary = await salesSummary.getSalesSummary(start, end);
  return {
    dateRange: { start, end },
    summary
  };
}

module.exports = { buildDailyReport };
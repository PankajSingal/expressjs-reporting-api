const axios = require('axios');

async function query(queryObject) {
  try {
    const res = await axios.post('http://localhost:8888/druid/v2/sql/', queryObject, {
      headers: { 'Content-Type': 'application/json' }
    });
    return res.data;
  } catch (err) {
    console.error('Druid query error:', err);
    throw err;
  }
}

module.exports = { query };